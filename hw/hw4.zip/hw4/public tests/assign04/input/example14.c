// a relatively simple example program using an array

int main(void) {
  int arr[1], sum;

  arr[0] = 2;

  sum = arr[0] + 1;

  return sum;
}
