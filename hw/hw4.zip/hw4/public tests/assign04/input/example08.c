int main(void) {
  int a, b, c;

  a = 2;
  b = 3;
  c = 0;

  if (a + 2 == b) {
    c = 1;
  } else {
    c = 2;
  }

  return c;
}
