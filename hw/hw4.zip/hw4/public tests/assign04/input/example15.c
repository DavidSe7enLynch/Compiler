// test integer input

int read_i32(void);

int main(void) {
  int x, y;
  x = read_i32();
  y = read_i32();
  return x + y;
}
