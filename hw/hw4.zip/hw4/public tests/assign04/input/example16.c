// test string output

void print_str(const char *s);

int main(void) {
  print_str("Hello, world\n");
  return 0;
}
