int main(void) {
  int a, b, c;

  a = 2;
  b = 3;
  c = 1;

  if (a + 1 == b) {
    c = 0;
  }

  return c;
}
