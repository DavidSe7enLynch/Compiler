int sum(int a, int b) {
  int result;
  result = a + b;
  return result;
}

int main(void) {
  int x, y, z;
  x = 2;
  y = 3;
  z = sum(x, y);
  return z;
}
